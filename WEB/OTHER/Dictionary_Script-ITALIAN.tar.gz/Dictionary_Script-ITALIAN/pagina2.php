<?php
/**
 * Script da Dennis M.
 *
 */

// l'informazione del database
$db = mysql_connect("localhost","USER","PASS");
mysql_select_db("dict");

// ancora deviamo si processare
if(!isset($_GET['lang']) OR $_GET['lang'] != "en" AND $_GET['lang'] != "fer"){
  $_GET['lang'] = "it";
}

// per processare i variabili
if($_GET['lang'] == "it"){
  $query = mysql_query("SELECT * FROM words WHERE ITA='".mysql_escape_string($_GET['parola'])."'");
  $noparola = "La parola non esista.";
} else if($_GET['lang'] == "en"){
  $query = mysql_query("SELECT * FROM words WHERE ENG='".mysql_escape_string($_GET['parola'])."'");
  $noparola = "The word does no exist.";
} else {
  $query = mysql_query("SELECT * FROM words WHERE FER='".mysql_escape_string($_GET['parola'])."'");
  $noparola = "La parola non esista. (nel ferentino)";
}

// i errori
if(!isset($_GET['parola'])){
  print $noparola;
  exit;
}
if(mysql_num_rows($query) == 0){
  print $noparola;
  exit;
}

// possiamo si guardare la pagina adesso :)
while($row = mysql_fetch_array($query)){
  print "\"".$_GET['parola']."\" <i>(".strtoupper($_GET['lang']).")</i><hr>";
  if($_GET['lang'] != "it"){
    print "<strong>Italiano:</strong> ".stripslashes($row['ITA'])."<br />";
  }
  if($_GET['lang'] != "en"){
    print "<strong>English:</strong> ".stripslashes($row['ENG'])."<br />";
  }
  if($_GET['lang'] != "fer"){
    print "<strong>Ferentino:</strong> ".stripslashes($row['FER'])."<br />";
  }
}

// Finito :)
mysql_close($db);
?>