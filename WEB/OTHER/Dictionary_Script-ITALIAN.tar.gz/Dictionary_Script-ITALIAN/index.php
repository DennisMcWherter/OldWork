<?php
/**
 * Script da Dennis M.
 *
 */

// l'informazione del database
$db = mysql_connect("localhost","USER","PASS");
mysql_select_db("dict");

// se non si definire poi usi la lingua italiana e la lettera "a"
if(!isset($_GET['lang']) OR strtolower($_GET['lang']) != "en" AND strtolower($_GET['lang']) != "fer"){
  $_GET['lang'] = "it";
}
if(!isset($_GET['let'])){
  $_GET['let'] = "a";
}

// per processare i variabili
if($_GET['lang'] == "it"){
  $query = mysql_query("SELECT * FROM words WHERE ITA LIKE '".mysql_escape_string($_GET['let'])."%' ORDER BY ITA ASC");
  print "Tutte le parole si iniziando con \"".strtoupper($_GET['let'])."\":<br /><br />";
  $messaggio = "<a href=\"pagina2.php?lang=".$_GET['lang']."&parola=".stripslashes($row['ITA'])."\">".stripslashes($row['ITA'])."</a><br />";
} else if($_GET['lang'] == "en"){
  $query = mysql_query("SELECT * FROM words WHERE ENG LIKE '".mysql_escape_string($_GET['let'])."%' ORDER BY ENG ASC");
  print "All words beginning with \"".strtoupper($_GET['let'])."\":<br /><br />";
  $messaggio = "<a href=\"pagina2.php?lang=".$_GET['lang']."&parola=".stripslashes($row['ENG'])."\">".stripslashes($row['ENG'])."</a><br />";
} else {
  $query = mysql_query("SELECT * FROM words WHERE FER LIKE '".mysql_escape_string($_GET['let'])."%' ORDER BY FER ASC");
  print "Tutte le parole si inizando con \"".strtoupper($_GET['let'])."\": (nel ferentino)<br /><br />";
  $messaggio = "<a href=\"pagina2.php?lang=".$_GET['lang']."&parola=".stripslashes($row['ENG'])."\">".stripslashes($row['FER'])."</a><br />";
}

// Adesso monstriamo a tutto
while($row = mysql_fetch_array($query)){
  if($_GET['lang'] == "it"){
    print "<a href=\"pagina2.php?lang=".$_GET['lang']."&parola=".stripslashes($row['ITA'])."\">".stripslashes($row['ITA'])."</a><br />";
  } else if($_GET['lang'] == "en"){
    print "<a href=\"pagina2.php?lang=".$_GET['lang']."&parola=".stripslashes($row['ENG'])."\">".stripslashes($row['ENG'])."</a><br />";
  } else {
    print "<a href=\"pagina2.php?lang=".$_GET['lang']."&parola=".stripslashes($row['ENG'])."\">".stripslashes($row['FER'])."</a><br />";
  }
}

// finito :)
mysql_close($db);
?>