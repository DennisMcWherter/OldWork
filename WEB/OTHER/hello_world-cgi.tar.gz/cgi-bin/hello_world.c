/**
 * Hello World CGI Script (C Version) by Dennis M.
 *
 * I prefer this (although it needs to be compiled) because
 * I'm a C programmer ;)
 *
 * oh yeah, and because we're compiling it with GCC or whatever
 * you use, we can use normal comments ;)
 *
 */

#include <stdio.h>

int main(){
  // Our content type
  printf("Content-Type: text/html;charset=us-ascii\n\n");

  // Our page!
  // We're going to break it up line by line so you can
  // see what's going on here.
  printf("<html>\n");
  printf("<head><title>Hello World! :D</title></head>\n");
  printf("<body>\n");
  printf("<h1>Hello World!</h1>\n");
  printf("Hello world! C style ;)\n");
  printf("</body>\n");
  printf("</html>\n\n");

  // Let's terminate the program now :)
  return 0;
}
