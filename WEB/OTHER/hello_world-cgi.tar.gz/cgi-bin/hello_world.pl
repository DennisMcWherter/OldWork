#!/usr/bin/perl
# Hello World CGI Script (Perl Version) by Dennis M.
#
# Remember now, comments in Perl must begin with the '#' character

## Our content type ##
print "Content-type: text/html\n\n";

## Now print the page! ##
print "<html>\n
<head><title>Hello World! :D</title></head>\n
<body>\n
<h1>Hello World!</h1>\n
Hello World Script!\n
</body>\n
</html>";
