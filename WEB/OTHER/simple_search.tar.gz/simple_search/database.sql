CREATE TABLE `search` (
  `id` bigint(10) NOT NULL auto_increment,
  `name` varchar(32) NOT NULL,
  `url` varchar(32) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;
 
