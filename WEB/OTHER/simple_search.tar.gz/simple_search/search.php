<?php
/**
 * Search database script by Dennis M.
 *
 */

// MySQL Connect Info
// Just so script can be used easily...
define("DB_HOST", "localhost");
define("DB_USER", "USERNAME");
define("DB_PASS", "PASSWORD");
define("DB_NAME", "DATABASE");
define("DB_TABLE","RESULT_TABLE");

// MySQL Connection
mysql_connect(DB_HOST,DB_USER,DB_PASS);
mysql_select_db(DB_NAME);

// Do this all in a single document... so set default..
if(!isset($_GET['page'])){
  $_GET['page'] = "index";
}

// Now switch...
switch(strtolower($_GET['page'])){
  default:
    print "<form name=\"search\" method=\"post\" action=\"?page=results\">
           <p>Search Term: <input type=\"text\" name=\"query\" /></p>
           <p>Search Type: <input type=\"radio\" name=\"type\" value=\"exact\" checked /> Exact Match <input type=\"radio\" name=\"type\" value=\"like\" /> Similar Match</p>
           <p><input type=\"submit\" value=\"Search\" /></p>
           </form>";
    exit;
  break;
  case 'results':
    if($_POST['type'] == "exact"){
      $query = mysql_query("SELECT * FROM ".DB_TABLE." WHERE name='".mysql_escape_string($_POST['query'])."' ORDER BY id ASC");
    } else if($_POST['type'] == "like"){
      $query = mysql_query("SELECT * FROM ".DB_TABLE." WHERE name LIKE '%".mysql_escape_string($_POST['query'])."%' ORDER BY id ASC");
    }
    if($query){
      $i = 1;
      if(mysql_num_rows($query) != 0){
        while($row = mysql_fetch_array($query)){
          $name = $row['name'];
          $url  = $row['url'];
	  $results .= $i.". <a href=\"".$url."\">".$name."</a><br />\n";
          $i++;
        }
        print $results;
      } else {
        $results = "No results match your criteria!";
      }
    } else {
      print "MySQL Error:<br />".mysql_error();
    }
  break;
}
?>