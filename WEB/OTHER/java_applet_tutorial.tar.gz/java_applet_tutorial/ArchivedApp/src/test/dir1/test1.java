/**
 * Simple Java Applet by Dennis M.
 *
 */
// Remember.. STRUCTURE STRUCTURE STRUCTURE!
package test.dir1;

public class test1{
  public int randomTest(){
    System.out.println("Successfully called to external file!");
    return 1;
  }
}