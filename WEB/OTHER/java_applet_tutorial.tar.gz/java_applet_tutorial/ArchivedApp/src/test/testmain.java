/**
 * Simple Test Java Applet by Dennis M.
 *
 */
// Package should go according to structure!
package test;

// Imports
import java.applet.*;
import java.awt.*;
import test.dir1.test1; // We can import this because of "package"
			// and our structure!

public class testmain extends Applet{
  // Declare vars
  test1 test = new test1();

  // Start and stop functions.
  public void init(){
    System.out.println("init();");
  }
  public void stop(){
    System.out.println("stop();");
  }

  // Draw some text again
  public void paint(Graphics g){
    // This function included in dir1.test1
    if(test.randomTest() != 1){
      g.drawString("Did not load correctly!",20,20);
      System.out.println("Doh! bad load :(");
    } else {
      // Let's continue to give the params and values! :)
      g.drawString("Name:  "+getParameter("name"),20,20);
      g.drawString("Email: "+getParameter("email"),20,40);
      g.drawString("Sex:   "+getParameter("sex"),20,60);
      System.out.println("Success! :D");
    }
  }
}

  