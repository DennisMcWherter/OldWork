This is a free tutorial created by Dennis M.! You must give due credit
to Dennis M. if you use any part of this tutorial in your own works.

This tutorial among many others can be found at:
http://microsonic.org/

The direct link to this tutorial is:
http://microsonic.org/2009/04/20/creating-a-java-web-applet
