/**

 * HelloWorld.java by Dennis M.

 *

 * Simple tutorial! :)

 *

 */



// Import all necessary files
import java.applet.*;
import java.awt.*;

// Start with our class
public class HelloWorld extends Applet {
  public void init(){
    // Just begins the program
  }
  public void stop(){
    // Stop the program when page is left or browser
    // closed
  }
  // Allowed to do this because of AWT library
  public void paint(Graphics g){
    g.drawString("Hello World!",20,20);
    g.drawString("Your name is: "+getParameter("YourName"),20,40);
  }
}
