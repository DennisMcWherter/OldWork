<?php
/**
 * Semplice CAPTCHA di Dennis McWherter
 *
 */
// Iniziare le sessione
session_start();

if(isset($_POST['captcha'])){
  if($_POST['captcha'] == $_SESSION['session_captchaText']){
    print "Bravo! Tu hai entrata un buon valore! :)";
    $_POST['captcha'] = NULL;
  } else {
    print "Doh! Un male valore :(";
  }
} else {
  print "<form name=\"captcha\" method=\"post\" action=\"index.php?provi=vero\">
	<p>CAPTCHA: <input type=\"text\" name=\"captcha\" /></p>
	<p><input type=\"submit\" value=\"Provi\" /></p>
	</form>
	<p>L'immagine: <img src=\"immagine.php\" /></p>";
}

?>