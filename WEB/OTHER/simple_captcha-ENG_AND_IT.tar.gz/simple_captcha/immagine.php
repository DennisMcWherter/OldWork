<?php
/**
 * Semplice Captcha di Dennis M.
 *
 */

// Iniziare le sessione
session_start();

// Fare un hash - randomi caratteri
$md5_hash = md5(rand(0,999));

// Il testo - soli 5 caratteri (da 12-17)
$testo = substr($md5_hash,11,5);
$_SESSION['session_captchaText'] = $testo;

// Creare l'immagine
$altezza = 20;
$larghezza = 100;
$immagine = ImageCreate($larghezza,$altezza);

// I colori
$bianco = ImageColorAllocate($immagine,255,255,255);
$nero   = ImageColorAllocate($immagine,0,0,0);
$grigio = ImageColorAllocate($immagine,204,204,204);

ImageFill($immagine,0,0,$nero);

// Fare il testo in bianco cosi lo ci possiamo letture XD
ImageString($immagine,3,30,3,$testo,$bianco);

// I dettagli
ImageRectangle($immagine,0,0,$larghezza-1,$altezza-1,$grigio);
ImageLine($immagine,0,$altezza/2,$larghezza,$altezza/2,$grigio);
ImageLine($immagine,$larghezza/2,0,$larghezza/2,$altezza,$grigio);

// Ci debbiamo dire a il browser il nostro file tipo
header("Content-Type: image/jpeg");

// L'output
ImageJpeg($immagine);
ImageDestroy($immagine);

?>