<?php
/**
 * Birthday Script created by Dennis J. McWherter, Jr.
 *
 * (C) 2010 DENNIS J. MCWHERTER, JR. ALL RIGHTS RESERVED.
 */
class Node
{
	// For sake of keeping things similar to a usable environment
	var $field_work_start = array();
}

/**
 * checkBirthday function
 *
 * The function will check a birth date
 * and see if it is in the range of specified
 * days.
 *
 * @param $birthday
 *   Birth date parameter. Assumed to be in M d, Y form
 * @param $days
 *   The range of days to check where the birthday is
 * @return int
 *   0 if the birthday is _NOT_ within the proper range
 *   1 if the birthday _IS_ within the proper range
 */
function checkBirthday($birthday,$days)
{
	// Parse out the year of the birthday
	$pos      = strpos($birthday,",")+2; // Find the comma which separates the year
	$today	  = strtotime(date("M, d")); // Check if day is < Dec. 22. If not, we need to account for next year!

	// Check if the birthday is within the range and has not passed!
	if($today < strtotime("Dec 22")){
		$birthday = substr_replace($birthday,date("Y"),$pos,4); // Replace the year with current year
		if(strtotime($birthday) <= strtotime("+".$days." days") && strtotime($birthday) >= time()){
			return 1;
		}
	} else { // Less than 10 days left in our year.. check for January birthdays!
		if(!strstr($birthday,"December")){
			$birthday = substr_replace($birthday,date("Y")+1,$pos,4); // Replace the year with next year
			$year = date("Y")+1;
		} else { // Still December?
			$birthday = substr_replace($birthday,date("Y"),$pos,4); // Replace the year with current year
			$year = date("Y");
		}
		$day = (date("d")+10)-31; // 10 days from now is...

		if((strtotime($birthday) <= strtotime("January ".$day.", ".$year)) && strtotime($birthday) >= strtotime("December 25, 2010")){
			return 1;
		}
	}
	return 0;
}
	
$node[]  = new Node;

$node[0]->field_work_start[0]  = "January 1, 1970"; // First birthday is _NOT_ within range
$node[1]->field_work_start[0] = "July 20, 1970"; // Second birthday _IS_ within range

for($i=0;$i<count($node);$i++){
	if(!checkBirthday($node[$i]->field_work_start[0],10)){
		print $node[$i]->field_work_start[0]." is not within the 10 day range.<br /><br />";
	} else {
		print $node[$i]->field_work_start[0]." is within the 10 day range.<br /><br />";
	}
}

unset($node);

?>