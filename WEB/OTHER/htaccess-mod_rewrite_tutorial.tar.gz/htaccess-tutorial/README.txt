Tutorial by Dennis M. This is a rough example on creating SEO friendly URL's. If you need more assistance, feel
free to contact me at dennis@microsonic.org or visit the blog at http://microsonic.org.