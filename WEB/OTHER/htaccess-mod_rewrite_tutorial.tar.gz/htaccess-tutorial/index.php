<?php
/**
 * .htaccess Tutorial by Dennis M.
 *
 * This is just the example script where we will
 * be redirected to and will do all our work! :)
 *
 */

if(!$_GET['p']){
  $_GET['p'] = "default";
}

// Define our pages:
switch($_GET['p']){
  // Default page if unknown page, etc.
  default:
    print "Default page!<br /><br />Try:<br /><a href=\"page-1.html\">Page1</a><br /><a href=\"page-2.html\">Page2</a><br />
      or <a href=\"page-3.html\">Page3</a> (Redirects back here! :D)";
  break;
  case 1:
    print "This is page one, congratulations! If you're accessing this through ?p=1 then you're not using SEO friendly
      url's. If you're using page-1.html then you have successfully created an SEO friendly rewrite!";
  break;
  case 2:
    print "This is page one, congratulations! If you're accessing this through ?p=2 then you're not using SEO friendly
      url's. If you're using page-2.html then you have successfully created an SEO friendly rewrite!";
  break;
}

?>