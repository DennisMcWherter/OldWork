<?php
/**
 * External Form Script
 * 
 * File: admin/lib/Main.php
 * Description: Admin functions :) - Yes, all of theme ;)
 *
 * Author: Dennis McWherter
 *
 */
if(!defined("ADMIN_SCRIPT")){
  print "Unauthorized Access!";
  exit;
}

class Admin_Base
{
  /**
   * Global vrZZ!
   *
   */
  var $MAIN;

  /**
   * Check Admin before everything :)
   *
   */
  function checkAdmin()
  {
    if(!$_SESSION['username']){
      $this->MAIN->errormsg = "No user logged in!";
      print $this->MAIN->site->page("error");
      return false;
    }
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE user='".$this->MAIN->db->escape($_SESSION['username'])."'");
    $this->MAIN->db->query();
    $row = $this->MAIN->db->_array();
    if($row['perms'] != "Admin"){
      $this->MAIN->errormsg = "User not admin!";
      print $this->MAIN->site->page("error");
      return false;
    }
    return true;
  }

  /**
   * List Users & Forms
   *
   */
  function _list($obj="users",$pageno=1)
  {
    $this->checkAdmin(); // Important prelim for all functions - Redundant, yes. But for security

    // Define the overall pagination settings
    $linkno   = 1; // Starting point for links
    $limit    = 10*($pageno-1); // Make sure we see all results ;)

    if($obj == "users"){
      // Women and queries first please...
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users");
      $this->MAIN->db->query();
      $numPages = $this->MAIN->db->num_rows()/10; // 10 results per page. Divide total results by that and voila
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users ORDER BY user ASC LIMIT ".$limit.",10;");
      if(!$this->MAIN->db->query()){
        $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
        print str_replace("theme","../theme",$this->MAIN->site->page("error"));
        return false;
      }
      $this->MAIN->statichead = "List All Users";
      $this->links = "<p align=\"right\">";
      while($row = $this->MAIN->db->_array()){
        $id   = stripslashes($row['id']);
        $name = stripslashes($row['user']);
        $this->list[] = "<a href=\"?act=edituser&id=".$id."\">".$name."</a><br />";
      }
      if($numPages > round($numPages)){
	while($links <= round($numPages)){
	  $this->links .= "<a href=\"?act=listusers&page=".$linkno."\">".$linkno."</a> ";
	  $links++;
	  $linkno++;
	}
      } else {
	while($links < round($numPages)){
	  $this->links .= "<right><a href=\"?act=listusers&page=".$linkno."\">".$linkno."</a></right> ";
	  $links++;
	  $linkno++;
	}
      }
      $this->links .= "</p>";
      $this->MAIN->staticmsg = implode($this->list);
      $this->MAIN->staticmsg .= $this->links;
      print str_replace("theme","../theme",$this->MAIN->site->page("static"));
      return true;
    } else if($obj == "forms"){
      // Thank you kind sir, the last few queries, I promise :)
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms");
      $this->MAIN->db->query();
      $numPages = $this->MAIN->db->num_rows()/10; // 10 results per page. Divide total results by that and voila
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms ORDER BY formname ASC");
      if(!$this->MAIN->db->query()){
        $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
        print str_replace("theme","../theme",$this->MAIN->site->page("error"));
        return false;
      }
      $this->MAIN->statichead = "List All Forms";
      $this->links = "<p align=\"right\">";
      while($row = $this->MAIN->db->_array()){
        $id    = stripslashes($row['id']);
        $name  = stripslashes($row['formname']);
        $owner = stripslashes($row['formowner']);
        $this->list[] = "<a href=\"?act=editform&id=".$id."\">".$name."</a><i>(".$name.")</i><br />";
      }
      if($numPages > round($numPages)){
	while($links <= round($numPages)){
	  $this->links .= "<a href=\"?act=listforms&page=".$linkno."\">".$linkno."</a> ";
	  $links++;
	  $linkno++;
	}
      } else {
	while($links < round($numPages)){
	  $this->links .= "<right><a href=\"?act=listforms&page=".$linkno."\">".$linkno."</a></right> ";
	  $links++;
	  $linkno++;
	}
      }
      $this->links .= "</p>";
      $this->MAIN->staticmsg = implode($this->list);
      $this->MAIN->staticmsg .= $this->links;
      print str_replace("theme","../theme",$this->MAIN->site->page("static"));
      return true;
    }
    return false;
  }

  /**
   * All form and user info
   *
   *
   */
  function info($id,$obj="user")
  {
    $this->checkAdmin();
    if($obj == "user"){
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE id='".$id."'");
      $this->MAIN->db->query();
      $this->MAIN->userinfo = $this->MAIN->db->_array();
      return $this->MAIN->userinfo;
    } else if($obj == "form"){
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE id='".$id."'");
      $this->MAIN->db->query();
      $this->MAIN->forminfo = $this->MAIN->db->_array();
      return $this->MAIN->forminfo;
    }
    return false;
  }

  /**
   * Edit user info now
   *
   *
   */
  function editUser($id,$user,$pass,$email,$status,$perms)
  {
    $this->checkAdmin();
    $this->info($id);

    // Make sure user exists...
    if($this->MAIN->db->num_rows() <= 0){
      $this->MAIN->errormsg = "User does not exist!";
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    }
    $this->MAIN->db->build_query("UPDATE {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users SET
				user='".$this->MAIN->db->escape($user)."',
				password='".$this->MAIN->db->escape(md5($pass))."',
				email='".$this->MAIN->db->escape($email)."',
				status='".$this->MAIN->db->escape($status)."',
				perms='".$this->MAIN->db->escape($perms)."'
				WHERE id='".$id."'");

    if(!$this->MAIN->db->query()){
      $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    }
    $this->MAIN->successmsg = "User edited successfully!";
    print str_replace("theme","../theme",$this->MAIN->site->page("success"));
    return true;
  }

  /**
   * And wonderful :)
   * Edit the form info
   *
   */
  function editForm($id,$name,$code,$domain,$page,$owner,$sendto,$redirect,$data,$status)
  {
    $this->checkAdmin();
    $this->info($id,"form");

    // Make sure exists...
    if($this->MAIN->db->num_rows() <= 0){
      $this->MAIN->errormsg = "User does not exist!";
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    }
    $this->MAIN->db->build_query("UPDATE {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms SET
				formname='".$name."',
				formcode='".$code."',
				formdomain='".$domain."',
				formpage='".$page."',
				formowner='".$owner."',
				formsendto='".$sendto."',
				formredirect='".$redirect."',
				formdata='".$data."',
				status='".$status."'
				WHERE id='".$id."'");
    if(!$this->MAIN->db->query()){
      $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    }
    $this->MAIN->successmsg = "Form successfully edited!";
    print str_replace("theme","../theme",$this->MAIN->site->page("success"));
    return true;
  }

  /**
   * Delete User
   *
   *
   */
  function deluser($id)
  {
    $this->checkAdmin();

    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE id='".$this->MAIN->db->escape($id)."'");
    $this->MAIN->db->query();

    if($this->MAIN->db->num_rows() == 0){
      $this->MAIN->errormsg = "User does not exist...";
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    }

    // Everything looks good.. Let's continue
    $this->MAIN->db->build_query("DELETE FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE id='".$this->MAIN->db->escape($id)."'");

    if(!$this->MAIN->db->query()){
      $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    } else {
      $this->MAIN->successmsg = "User deleted successfully!";
      print str_replace("theme","../theme",$this->MAIN->site->page("success"));
      return true;
    }
    return false;
  }

  /**
   * Delete User
   *
   *
   */
  function delform($id)
  {
    $this->checkAdmin();

    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE id='".$this->MAIN->db->escape($id)."'");
    $this->MAIN->db->query();

    if($this->MAIN->db->num_rows() == 0){
      $this->MAIN->errormsg = "Form does not exist...";
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    }

    // Everything looks good.. Let's continue
    $this->MAIN->db->build_query("DELETE FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE id='".$this->MAIN->db->escape($id)."'");

    if(!$this->MAIN->db->query()){
      $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
      print str_replace("theme","../theme",$this->MAIN->site->page("error"));
      return false;
    } else {
      $this->MAIN->successmsg = "Forms deleted successfully!";
      print str_replace("theme","../theme",$this->MAIN->site->page("success"));
      return true;
    }
    return false;
  }

  /**
   * View Form Data
   *
   */
  function viewData($id)
  {
    $this->checkAdmin();
    $this->MAIN->user->grabForm($id);

    print "<h1>All Form Data</h1>".str_replace("\n","<br />",$this->MAIN->formdata['formdata'])."<br /><right><a href=\"?act=listforms\">Back</a>";
    return true;
  }
}
?>