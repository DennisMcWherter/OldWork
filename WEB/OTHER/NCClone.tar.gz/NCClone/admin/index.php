<?php
/**
 * External Form Script
 *
 * File: admin/index.php
 * Description: Admin main page
 *
 * Author: Dennis McWherter
 *
 */
require_once("../init.php");
require_once("../config.php");
define("IS_SCRIPT",true);
define("ADMIN_SCRIPT",true);

// Grab our essential libs! :)
require_once(CORE_PATH . "/Main.php");
require_once(CORE_PATH . "/SQL/Base.php");
require_once(CORE_PATH . "/Site/Base.php");
require_once(CORE_PATH . "/Sessions/Base.php");
require_once(CORE_PATH . "/Users/Base.php");
require_once(ADMIN_CORE_PATH . "/Main.php");

// Now initiate!
$MAIN         = new MAIN;
$MAIN->config = $config;

$MAIN->sql_connect();

$MAIN->site          = new Site_Base;
$MAIN->site->MAIN    =& $MAIN;
$MAIN->session       = new Sessions_Base;
$MAIN->session->MAIN =& $MAIN;
$MAIN->user	     = new Users_Base;
$MAIN->user->MAIN    =& $MAIN;
$MAIN->admin	     = new Admin_Base;
$MAIN->admin->MAIN   =& $MAIN;

switch($_GET['act']){
  default:
    $MAIN->statichead = "Admin Control Panel";
    $MAIN->staticmsg  = "<p>Please use the options below:<br />
			<a href=\"?act=listusers\">List Users</a><br />
			<a href=\"?act=listforms\">List Forms</a><br /></p>
			<p align=\"right\"><a href=\"../?act=index\">Home</a><br />
			<a href=\"../?act=logout\">Logout</a></p>";
    print str_replace("theme","../theme",$MAIN->site->page("static"));
    exit;
  break;
  case 'listusers':
    if($_GET['page'] == ""){
      $_GET['page'] = 1;
    }
    $MAIN->admin->_list("users",$_GET['page']);
    exit;
  break;
  case 'edituser':
    if(!isset($_GET['id'])){
      $MAIN->errormsg = "No user exists...";
      print str_replace("theme","../theme",$MAIN->site->page("error"));
      exit;
    } else {
      if($_GET['go'] == "true"){
        $MAIN->admin->editUser($_GET['id'],$_POST['user'],$_POST['pass'],$_POST['email'],$_POST['status'],$_POST['perms']);
      } else {
        $MAIN->admin->info($_GET['id']);
        $MAIN->statichead = "Edit User";
        $MAIN->staticmsg  = "<form name=\"edituser\" method=\"post\" action=\"?act=edituser&id=".$_GET['id']."&go=true\">
			<label>Username:</label><p> <input type=\"text\" name=\"user\" value=\"".$MAIN->userinfo['user']."\" /></p>
			<label>Password:</label><p> <input type=\"text\" name=\"pass\" /> <i>(Leave blank if not changing)</i></p>
			<label>Email:</label><p> <input type=\"text\" name=\"email\" value=\"".$MAIN->userinfo['email']."\" /></p>
			<label>Status:</label><p> <select name=\"status\">
						<option name=\"status\" value=\"Active\">Active</option>
						<option name=\"status\" value=\"Suspended\">Suspended</option>
						<option name=\"status\" value=\"Pending\">Pending</option>
						</select></p>
			<label>Permissions:</label><p> <select name=\"perms\">
						<option name=\"perms\" value=\"User\">User</option>
						<option name=\"perms\" value=\"Admin\">Admin</option>
						</select></p>
			<p><input type=\"submit\" value=\"Edit\" /><right><a href=\"?act=deluser&id=".$_GET['id']."\">Delete User</a></right></p>
			</form>";
	print str_replace("theme","../theme",$MAIN->site->page("static"));
	exit;
      }
    }
  case 'listforms':
    if($_GET['page'] == ""){
      $_GET['page'] = 1;
    }
    $MAIN->admin->_list("forms",$_GET['page']);
  break;
  case 'editform':
    if(!isset($_GET['id'])){
      $MAIN->errormsg = "No form exists...";
      print str_replace("theme","../theme",$MAIN->site->page("error"));
      exit;
    } else if($_GET['go'] == "true"){
      $MAIN->admin->editForm($_GET['id'],$_POST['name'],$_POST['code'],$_POST['domain'],$_POST['page'],$_POST['owner'],$_POST['sendto'],$_POST['redirect'],$_POST['data'],$_POST['status']);
    } else {
	$MAIN->admin->info($_GET['id'],"form");
	$MAIN->db->build_query("SELECT user FROM {$MAIN->db->escape($MAIN->config['prefix'])}_users ORDER BY user ASC");
	$MAIN->db->query();
        $MAIN->statichead = "Edit Form";
        $MAIN->staticmsg[]  = "<form name=\"editform\" method=\"post\" action=\"?act=editform&id=".$_GET['id']."&go=true\">
			<label>Form Name:</label> <input type=\"hidden\" name=\"name\" value=\"".$MAIN->forminfo['formname']."\" /><b>".$MAIN->forminfo['formname']."</b></label><br />
			<label>Form Code:</label><p> <textarea name=\"code\">".$MAIN->forminfo['formcode']."</textarea></p>
			<label>Domain:</label><p> <input type=\"text\" name=\"domain\" value=\"".$MAIN->forminfo['formdomain']."\" /></p>
			<label>Page:</label><p> <textarea name=\"page\">".$MAIN->forminfo['formpage']."</textarea></p>
			<label>Owner: <select name=\"owner\">
			<option name=\"owner\" value=\"".$MAIN->forminfo['formowner']."\">".$MAIN->forminfo['formowner']."*</option>";
	while($row = $MAIN->db->_array()){
	  $val = stripslashes($row['user']);
	  if($row['user'] != $MAIN->forminfo['formowner']){
	    $MAIN->staticmsg[] .= "<option name=\"owner\" value=\"".$val."\">".$val."</option>\n";
          }
	}
	$MAIN->staticmsg[] .= "</select></label><br />
			<label>Sendto:</label><p> <input type=\"text\" name=\"sendto\" value=\"".$MAIN->forminfo['formsendto']."\" /></p>
			<label>Redirect:</label><p> <input type=\"text\" name=\"redirect\" value=\"".$MAIN->forminfo['formredirect']."\" /></p>
			<!--<label>Data:</label><p> <input type=\"text\" name=\"data\" value=\"".$MAIN->forminfo['formdata']."\" /></p>-->
			<label>Status: <select name=\"status\">
						<option name=\"status\" value=\"Active\">Active</option>
						<option name=\"status\" value=\"Inactive\">Inactive</option>
						</select></p>
			<p><input type=\"submit\" value=\"Edit\" /></label><right><a href=\"?act=viewdata&id=".$_GET['id']."\">View Data</a> | <a href=\"?act=delform&id=".$_GET['id']."\">Delete Form</a></right>
			</form>";
	$MAIN->staticmsg = implode($MAIN->staticmsg);
	print str_replace("theme","../theme",$MAIN->site->page("static"));
	exit;
    }
  break;
  case 'deluser':
    if(!$_GET['id']){
      $MAIN->errormsg = "User does not exist...";
      print str_replace("theme","../theme",$MAIN->site->page("error"));
      exit;
    } else {
      $MAIN->admin->deluser($_GET['id']);
    }
  break;
  case 'delform':
    if(!$_GET['id']){
      $MAIN->errormsg = "Form does not exist...";
      print str_replace("theme","../theme",$MAIN->site->page("error"));
      exit;
    } else {
      $MAIN->admin->delform($_GET['id']);
    }
  break;
  case 'viewdata':
    if(!$_GET['id']){
      print "Form doesn't exist...";
      exit;
    } else {
      $MAIN->admin->viewdata($_GET['id']);
    }
  break;
}
?>