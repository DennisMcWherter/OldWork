<?php
/**
 * External Form Script
 *
 * File: index.php
 * Description: Main site file
 *
 * Author: Dennis McWherter
 *
 */
require_once("init.php"); // Obviously need to make everything work :)
if(file_exists(ROOT_PATH . "/config.php")){
  $config = array();
  require_once(ROOT_PATH . "/config.php"); // Our config files are important
}
define("IS_SCRIPT", true); // Allow script access

// Allow debug mode :)
if(!isset($_GET['debug'])){
  error_reporting(0);
}

// Make sure things check out ok
if(!defined("INIT_SUCCESS")){
  print "<h1>Internal Server Error</h1>".PHP_EOL;
  print "There was problem loading the site! Please contact your
         server administrator as soon as possible!";
  exit;
}

// Make sure we're properly installed
if(!$config && !$debug){
  print "<h1>Error!</h1>".PHP_EOL;
  print "Please visit the <a href=\"install\">install</a> directory to install your site!";
  exit;
}

// All checks OK?! Then let's not let someone overwrite our install :)
if(file_exists("install")){
  print "<h1>Security Error!</h1>".PHP_EOL;
  print "Please remove your \"install\" directory before continuing.";
  exit;
}

// Let's make sure we grab everything ok...
require_once(CORE_PATH . "/Main.php");
require_once(CORE_PATH . "/SQL/Base.php");
require_once(CORE_PATH . "/Sessions/Base.php");
require_once(CORE_PATH . "/Site/Base.php");
require_once(CORE_PATH . "/Users/Base.php");

// Here we goooooooooo!
$MAIN                = new MAIN;
$MAIN->config        = $config;

$MAIN->sql_connect(); // Connect to SQL

$MAIN->site          = new Site_Base;
$MAIN->site->MAIN    =& $MAIN;
$MAIN->session       = new Sessions_Base;
$MAIN->session->MAIN =& $MAIN;
$MAIN->user          = new Users_Base;
$MAIN->user->MAIN    =& $MAIN;

// Uh-oh... Errors!? :S
if($MAIN->errors > 0){
  print $MAIN->error_page;
  exit;
}

// Users page :)
if($_GET['act'] == "users"){
  switch($_GET['page']){
    default:
      $MAIN->user->isLoggedIn();
      print $MAIN->site->page("users");
      exit;
    break;
    case 'listforms':
      $MAIN->user->listForms();
    break;
    case 'newform':
      if($_GET['go'] == "true"){
        if($_POST['form'] == "true"){
	  if($_POST['store'] != "true"){
	    $store = false;
	  } else {
	    $store = true;
	  }
	  print $MAIN->user->createForm($_POST['name'],addslashes($_POST['code']),$_POST['domain'],addslashes($_POST['page']),$_SESSION['username'],$store,$_POST['sendto'],$_POST['redirect']);
	  exit;
        } else {
	  print $MAIN->site->page("users");
	  exit;
	}
      }
    break;
    case 'delform':
      if($_GET['act'] == "users" AND $_GET['id']){
	print $MAIN->user->delForm($_GET['id']);
	exit;
      } else {
	print $MAIN->site->page("users");
	exit;
      }
    break;
    case 'edituser':
      if($_GET['go'] == "true"){
        print $MAIN->user->editInfo($_SESSION['username'],$_POST['pass1'],$_POST['pass2'],$_POST['email']);
	exit;
      } else {
        $MAIN->db->build_query("SELECT * FROM {$MAIN->db->escape($MAIN->config['prefix'])}_users WHERE user='".$MAIN->db->escape($_SESSION['username'])."'");
        $MAIN->db->query();
        $data = $MAIN->db->_array();
        $MAIN->statichead = "Edit Account Information";
        $MAIN->staticmsg  = "<form name=\"editacct\" method=\"post\" action=\"?act=users&page=edituser&go=true\">
		<p>Username:</p><p> ".$_SESSION['username']."</p>
		<p>Password:</p><p> <input type=\"password\" name=\"pass1\" /> <i>(Leave blank if not changing)</i></p>
		<p>Password Again:</p><p> <input type=\"password\" name=\"pass2\" /></p>
		<p>Email:</p><p> <input type=\"text\" name=\"email\" value=\"".$data['email']."\" /></p>
		<p><input type=\"submit\" value=\"Edit\" /></p>
		</form>";
        print $MAIN->site->page("static");
        exit;
      }
    break;
    case 'editform':
      if(!isset($_GET['id'])){
	$MAIN->errormsg = "Please edit a valid form!";
	print $MAIN->site->page("error");
	exit;
      } else {
	if($_GET['go'] == "true"){
	  print $MAIN->user->editForm($_GET['id']);
	  exit;
	} else {
	  $MAIN->user->grabForm($_GET['id']);
	  $MAIN->statichead = "Edit Form";
	  $MAIN->staticmsg  = "<form name=\"editform\" method=\"post\" action=\"?act=users&page=editform&id=".$_GET['id']."&go=true\">
	  <p>Name: <b>".$MAIN->formname."</b></p>
	  <label>Code:</label><p> <textarea name=\"code\">".$MAIN->formdata['code']."</textarea></p>
	  <label>Page:</label><p> <textarea name=\"page\">".$MAIN->formdata['page']."</textarea></p>
  	  <label>Domain:</label><p> <input type=\"text\" name=\"domain\" value=\"".$MAIN->formdata['domain']."\" /></p>
	  <label>Send To:</label><p> <input type=\"text\" name=\"sendto\" value=\"".$MAIN->formdata['sendto']."\" /></p>
    	  <label>Redirect:</label><p> <input type=\"text\" name=\"redirect\" value=\"".$MAIN->formdata['redirect']."\" /></p>
	  <label>Status:</label><p> <select name=\"status\"><option name=\"status\" value=\"Active\" />Active
	  <option name=\"status\" value=\"Inactive\" />Inactive
	  </select></p>
	  <input type=\"hidden\" name=\"inform\" value=\"true\" />
	  <p><input type=\"submit\" value=\"Edit Form\" /></p>
	  </form>";
	  print $MAIN->site->page("static");
	  exit;
	}
    }
  break;
  case 'viewdata':
    if(!$_GET['id']){
      $MAIN->errormsg = "Form does not exist...";
      print $MAIN->site->page("error");
      exit;
    } else {
      $MAIN->user->viewData($_GET['id']);
      exit;
    }
  break;
   }
}

// Ok... Should be the last few edits I do on this! :D
// But already Thursday, February 5, 2009 D: (Gone on far too long XD about a week ha)
if($_GET['act'] == "resetpass"){
  if(isset($_GET['user'])){
    $MAIN->session->resetPass($_GET['user'],$_SERVER['REMOTE_ADDR']);
    $MAIN->successmsg = "Password for ".$_GET['user']." successfully reset! Please check your e-mail!";
    print $MAIN->site->page("success");
    exit;
  } else {
    $MAIN->statichead = "Reset Password!";
    $MAIN->staticmsg  = "<h1>Please enter your username:</h1>
			<form name=\"resetpass\" method=\"post\" action=\"?act=resetpass&user=".$_POST['user']."\">
			<p>User: <input type=\"text\" name=\"user\" /></p>
			<p><input type=\"submit\" value=\"Reset Pass\" /></p>
			</form>";
    print $MAIN->site->page("static");
    exit;
  }
}

// Make sure logged in users don't go to register!
if($_SESSION['username']){
  if($_GET['act'] == "register"){
    print $MAIN->site->page("index");
    exit;
  }
}

// Login/Logout stuff
if($_GET['act'] == "login" && $_GET['go'] == "true"){
  if($_POST['form'] == "true"){
    $MAIN->session->login($_POST['user'],$_POST['pass']);
  } else {
    print $MAIN->site->page("index");
  }
}

if($_GET['act'] == "logout"){
  $MAIN->session->logout();
  exit;
}

// Let's print the page
$action = join("&",$_GET);
print $MAIN->site->page($action);
?>