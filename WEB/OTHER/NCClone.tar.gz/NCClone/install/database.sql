-- --------------------------------------------------------

-- 
-- Table structure for table `site_forms`
-- 

CREATE TABLE `[dbprefix]_forms` (
  `id` bigint(10) NOT NULL auto_increment,
  `formname` varchar(32) NOT NULL,
  `formcode` text NOT NULL,
  `formdomain` varchar(32) NOT NULL,
  `formpage` text NOT NULL,
  `formowner` varchar(32) NOT NULL,
  `formsendto` varchar(32) NOT NULL,
  `formredirect` varchar(32) NOT NULL,
  `formdata` longtext NOT NULL,
  `status` enum('Active','Inactive') NOT NULL default 'Active',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `site_settings`
-- 

CREATE TABLE `[dbprefix]_settings` (
  `id` bigint(10) NOT NULL auto_increment,
  `title` varchar(32) NOT NULL,
  `slogan` varchar(64) NOT NULL,
  `siteurl` varchar(32) NOT NULL,
  `companyname` varchar(64) NOT NULL,
  `owneremail` varchar(64) NOT NULL,
  `mailbody` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `site_users`
-- 

CREATE TABLE `[dbprefix]_users` (
  `id` bigint(10) NOT NULL auto_increment,
  `user` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `perms` enum('User','Admin') NOT NULL default 'User',
  `ip` varchar(16) NOT NULL,
  `regdate` date NOT NULL,
  `lastlogin` date NOT NULL,
  `status` enum('Active','Suspended','Pending') NOT NULL default 'Pending',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ;
