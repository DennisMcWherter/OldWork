<?php
/**
 * External Form Script
 *
 * File: install/index.php
 * Description: Make the site work :D
 *
 * Author: Dennis McWherter
 *
 */
if(!isset($_GET['step']) || empty($_GET['step'])){
  header('Location: ?step=1');
}
switch($_GET['step'])
{
  case '1':
?>
<html>
<head>
<title>External Form Script Installer</title>
</head><body>
<form action="?step=2" method="POST">

<b>SQL Information</b>

Hostname/IP:
<input type="text" name="sql_site_hostname" value="localhost"><br>
Username:
<input type="text" name="sql_site_username"><br>
Password:
<input type="password" name="sql_site_password"><br>
Database:
<input type="text" name="sql_site_database"><br>
Database Prefix:
<input type="text" name="sql_site_dbprefix"> (Default value is site_: don't include the underscore)<br>
<br>
<input type="submit" value="->">
</form>
</body>
</html>
<?php break;
	case '2':
  // Test to make sure connection works!
  mysql_connect($_POST['sql_site_hostname'],$_POST['sql_site_username'],$_POST['sql_site_password']) or die("Could not connect. Please correct the informations. <meta http-equiv='refresh' content='2;url=./?step=1'>");
  mysql_select_db($_POST['sql_site_database']) or die("Could not connect. Please correct the informations. <meta http-equiv='refresh' content='2;url=./?step=1'>");
  mysql_close();
?>
<html><head>
<title>External Form Script Installer - Site settings</title>
</head><body>
<form action="?step=3" method="POST"><?php
print "<input type=\"hidden\" name=\"sql_site_hostname\" value=\"".$_POST['sql_site_hostname']."\"><input type=\"hidden\" name=\"sql_site_username\" value=\"".$_POST['sql_site_username']."\"><input type=\"hidden\" name=\"sql_site_password\" value=\"".$_POST['sql_site_password']."\"><input type=\"hidden\" name=\"sql_site_database\" value=\"".$_POST['sql_site_database']."\"><input type=\"hidden\" name=\"sql_logon_hostname\" value=\"".$_POST['sql_logon_hostname']."\"><input type=\"hidden\" name=\"sql_logon_username\" value=\"".$_POST['sql_logon_username']."\"><input type=\"hidden\" name=\"sql_logon_password\" value=\"".$_POST['sql_logon_password']."\"><input type=\"hidden\" name=\"sql_logon_database\" value=\"".$_POST['sql_logon_database']."\"><input type=\"hidden\" name=\"sql_site_dbprefix\" value=\"".$_POST['sql_site_dbprefix']."\"><input type=\"hidden\" name=\"sql_char_hostname\" value=\"".$_POST['sql_char_hostname']."\"><input type=\"hidden\" name=\"sql_char_username\" value=\"".$_POST['sql_char_username']."\"><input type=\"hidden\" name=\"sql_char_password\" value=\"".$_POST['sql_char_password']."\"><input type=\"hidden\" name=\"sql_char_database\" value=\"".$_POST['sql_char_database']."\"><input type=\"hidden\" name=\"sql_realm_name\" value=\"".$_POST['sql_realm_name']."\"><input type=\"hidden\" name=\"sql_realm_ip\" value=\"".$_POST['sql_realm_ip']."\"><input type=\"hidden\" name=\"sql_realm_port\" value=\"".$_POST['sql_realm_port']."\"><input type=\"hidden\" name=\"sql_realm_gms\" value=\"".$_POST['sql_realm_gms']."\"><input type=\"hidden\" name=\"char_enc_password\" value=\"".$_POST['char_enc_password']."\">";?>

<b>Site setup</b>

Sitename:
<input type="text" name="site_name"><br>
Slogan: (Sitename - Slogan)
<input type="text" name="site_slogan"><br>
Site URL:
<input type="text" name="site_url"><br>
Site E-mail: (Address main mail should come from)
<input type="text" name="site_email"><br>
Welcome Mailbody:
<textarea name="mailbody">Hello {USERNAME},

Thank you for registering at {SITENAME}! Below is your registration information:

      Username: {USERNAME}
      Password: {PASSWORD}

Now be sure to keep this information safe and write it down so you don't forget it.

      Your address is http://{SITE_URL}/users/{USERNAME}
      
Regards,
{SITENAME} Staff</textarea><br>
Company Name:
<input type="text" name="companyname"><br>
Administrator username:
<input type="text" name="site_admin_username"><br>
Administrator password:
<input type="text" name="site_admin_password"><br>
Administrator email:
<input type="text" name="site_admin_email"><br>
<input type="submit" value="->">
</form>
</body>
</html>
<?php 
  break;
  case "3":
		$msg = array();
		$msg[] = "<title>External Form Script Installer - Finishing...</title>\nCreating config file ...";
		$fp = fopen("../config.php", "w");
		$msg[] = " Done!\n";
		
		$msg[] = "Setting configuration variables ...";
		$sitehost  = $_POST['sql_site_hostname'];
		$siteuser  = $_POST['sql_site_username'];
		$sitepass  = $_POST['sql_site_password'];
		$sitedb    = $_POST['sql_site_database'];
		if($_POST['sql_site_dbprefix'] == ""){ $sitedbpfx = "site"; } else { $sitedbpfx = $_POST['sql_site_dbprefix']; }
		
		mysql_connect($sitehost, $siteuser, $sitepass); // Let's make a proper connection for
		mysql_select_db($sitedb); 		// mysql_real_escape_string so it doesn't return errors to us...
		$sitename  = mysql_real_escape_string($_POST['site_name']);
		$slogan    = mysql_real_escape_string($_POST['site_slogan']);
		$siteurl   = mysql_real_escape_string($_POST['site_url']);
		$siteemail = mysql_real_escape_string($_POST['site_email']);
		$mailbody  = mysql_real_escape_string($_POST['mailbody']);
		$company   = mysql_real_escape_string($_POST['companyname']);
		$adminuser = mysql_real_escape_string($_POST['site_admin_username']);
		$adminpass = mysql_real_escape_string($_POST['site_admin_password']);
		$adminemail= mysql_real_escape_string($_POST['site_admin_email']);

		$msg[] = " Done!\n";
		
		$msg[] = "Writing config.php ...";
		$content   = array();
		$content[] = "<?php";
		$content[] = "/**";
		$content[] = " * This file was created automatically by the installer script. :D";
		$content[] = " * No actions here are needed.";
		$content[] = " * edit at your own risk XD (so before doing it, write down WORKING";
		$content[] = " * settings FIRST! :D";
		$content[] = " */";
		$content[] = "";
		$content[] = "\$config['host']   = \"$sitehost\";";
		$content[] = "\$config['user']   = \"$siteuser\";";
		$content[] = "\$config['pass']   = \"$sitepass\";";
		$content[] = "\$config['db']     = \"$sitedb\";";
		$content[] = "\$config['prefix'] = \"$sitedbpfx\";";
		$content[] = "";
		$content[] = "?>";
		
		$finput = implode("\n", $content);
		fwrite($fp, $finput, strlen($finput));
		$msg[] = " Done!\n";
		fclose($fp);
		
		$msg[] = "Connecting to the database and creating ...";
		
		$dbfile = file_get_contents("database.sql");
		$squery = str_replace('[dbprefix]', $sitedbpfx, $dbfile);
		$sql = explode(";", $squery);
		foreach($sql as $query)
		{
			$q = mysql_query($query);
			if($q) {
				$msg[] = " Done!\n";
			} else {
				if(mysql_error() == "Query was empty")
				{
					$msg[] = "";
				} else {
					$msg[] = " ERROR: " .mysql_error() . "\n";
					$err++;
				}
			}
			// mysql_free_result($q); // Just commenting out for now but don't see the real need for it here? @ Dennis (RageD)
		}
		
		$msg[] = "Adding administrator account ...";
		if(mysql_query("INSERT INTO ".$sitedbpfx."_users 
			VALUES (NULL,'".$adminuser."','".md5($adminpass)."','".$adminemail."', 'Admin', '".$_SERVER['HTTP_ADDR']."', '".date(Y-m-d)."', '".date(Y-m-d)."', 'Active')") AND mkdir("../users/".$adminuser, 0777)) {
			$msg[] = " Done!\n";
		} else {
			if(mysql_error() == "Query was empty")
			{
				$msg[] = "";
			} else {
				$msg[] = " ERROR: " .mysql_error() . "\n";
				$err++;
			}
		}
		
		$msg[] = "Creating site settings ...";
		if(mysql_query("INSERT INTO ".$sitedbpfx."_settings SET title='".$sitename."', slogan='".$slogan."', siteurl='".$siteurl."', companyname='".$company."', owneremail='".$siteemail."', mailbody='".$mailbody."'")) {
			$msg[] =  " Done!\n";
		} else {
			if(mysql_error() == "Query was empty")
			{
				$msg[] = "";
			} else {
				$msg[] = " ERROR: " .mysql_error() . "\n";
				$err++;
			}
		}

		
		mysql_close();
		
		
		print implode(null, $msg);
		if(!$err) {
			print "\n\nYour website have been set up successfully!\n<a href='../'>Click here to see the result!</a>";
		} else {
			print "\n\n$err errors occured while installing the website. Please try again by <a href='./?step=1'>clicking here</a>.";
		}
		
		break;
	default: // This *No longer* breaks the script. Headers need to be sent first...
		print("<meta http-equiv='refresh' content='0;url=./?step=1' />");
		break;
}
?>