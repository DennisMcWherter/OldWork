<?php
/**
 * External Form Script
 *
 * File: register.php
 * Description: Process Registrations
 *
 * Author: Dennis McWherter
 *
 */
require_once("init.php");
require_once("config.php");
define("IS_SCRIPT", true);

// Classes once again...
require_once(CORE_PATH . "/Main.php");
require_once(CORE_PATH . "/SQL/Base.php");
require_once(CORE_PATH . "/Sessions/Base.php");
require_once(CORE_PATH . "/Site/Base.php");

// Initiate all the site stuff
$MAIN         = new MAIN;
$MAIN->config = $config;

$MAIN->sql_connect(); // SQL Connection

$MAIN->session       = new Sessions_Base;
$MAIN->session->MAIN =& $MAIN;
$MAIN->site	     = new Site_Base;
$MAIN->site->MAIN    =& $MAIN;

// Site working time :)
if($_SESSION['username']){
  // We're already logged in? No reason to be here -_-
  print $MAIN->site->page("index");
} else if($_POST['form'] != "true"){
  // Hmm. Let's show them the register page! :)
  print $MAIN->site->page("register");
} else {
  $MAIN->session->register($_POST['user'],$_POST['pass'],$_POST['email']);
}
?>