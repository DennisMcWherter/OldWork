<?php
/**
 * External Form Script
 *
 * File: users/process.php
 * Description: Process all form functions!
 *
 * Author: Dennis McWherter
 *
 */
if(!isset($_POST['redirect'])){
  print "Unauthorized Access!";
  exit;
}
// Generic processing file... Let's begin using our archaeic mysql functions :)
require_once("../config.php");
mysql_connect($config['host'],$config['user'],$config['pass']);
mysql_select_db($config['db']);

// We're connected now let's run proper queries while necessary
if($_POST['store'] != "false"){
  foreach($_POST as $key => $value){
    $data .= $key.": ".$value."\n";
  }
  if(!mysql_query("UPDATE ".$config['prefix']."_forms SET formdata=CONCAT(formdata, '\n\n".mysql_real_escape_string($data)."\n~~~~~~~~~~~~~~~~~~~')
		WHERE formowner='".$_POST['formowner']."' AND formname='".$_POST['formname']."'")){
	print "MySQL Error: <br />".mysql_error();
	exit;
  }
}

// Store data taken care of... Now let's try to.. send :D
if($_POST['mailto'] != "false"){
  foreach($_POST as $key => $value){
    $data .= $key.": ".$value."\n";
  }
  mail($_POST['mailto'],"New Form Information!","Latest form submission:\r\n".$data,"no-reply");
}

if($_POST['redirect'] != "false"){
  Header("Location: ".$_POST['redirect']);
}

print "Form Successfully sent!";
mysql_close();
?>