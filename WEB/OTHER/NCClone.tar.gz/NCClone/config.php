<?php
// Configuration file!

// Database Information
$config['user']   = "";
$config['pass']   = "";
$config['host']   = "";
$config['db']     = "";
$config['prefix'] = "site";

unset($config); // Edit your config file! :)

?>