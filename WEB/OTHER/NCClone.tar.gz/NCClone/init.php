<?php
/**
 * External Form Script
 *
 * File: init.php
 * Description: Initiate site properly 
 *
 * Author: Dennis McWherter
 *
 */

// There should be no need to touch this file!

session_start(); // Start our sessions because that's how kiddies login :)
define("ROOT_PATH", dirname(__FILE__)); // Define our Root path
define("CORE_PATH", ROOT_PATH."/lib"); // Where our main functions will be
define("THEME_PATH", ROOT_PATH."/theme"); // Theme directory :D
define("USER_PATH", ROOT_PATH."/users"); // Users directory ;)
define("ADMIN_CORE_PATH", ROOT_PATH."/admin/lib"); // Admin functions
define("INIT_SUCCESS", true); // If this doesn't happen, something failed! :(
?>