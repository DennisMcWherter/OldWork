<?php
/**
 * External Form Script
 *
 * File: lib/Site/Base.php
 * Description: Site theme, etc. All pages here!
 *
 * Author: Dennis McWherter
 *
 */
if(!defined("IS_SCRIPT")){
  print "Unauthorized Access";
  exit;
}

class Site_Base
{
  /**
   * Global Var :) w00t
   *
   */
  var $MAIN;

  /**
   * Page info ;)
   *
   * @var array
   *
   */
  var $pageinfo = array();

  /**
   * Database object
   *
   * @var object
   *
   */
  var $db;

  /**
   * Config var
   *
   * @var array
   *
   */
  var $config = array();

  /**
   * Visible page! :D
   *
   * @var string
   *
   */
  var $page;

  /**
   * The core of the site! All stored in arrays!
   *
   * @param string $action
   *
   */
  function page($action)
  {
    // Get page vars from Database
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_settings LIMIT 1;");
    $this->MAIN->db->query(); // Execute
    while($row = $this->MAIN->db->_array()){
      $title      = stripslashes($row['title']);
      $slogan     = stripslashes($row['slogan']);
      $company    = stripslashes($row['companyname']);
      $owneremail = stripslashes($row['owneremail']);
      $siteurl    = stripslashes($row['siteurl']);
    }

    // Declare static vars
    $errormsg   = $this->MAIN->errormsg;
    $successmsg = $this->MAIN->successmsg;
    $statichead = $this->MAIN->statichead;
    $staticmsg  = $this->MAIN->staticmsg;
    $copyright  = $this->MAIN->copyright;
    if($this->MAIN->forms != NULL){ $forms = implode($this->MAIN->forms); }

    // Sub-array definitions - was going to do switch($var) but already started on this XD
    list($act1,$act2,$act3)  = split("&",$action);
    if($act2 == NULL){ $act2 = "index"; }
    //$act3 = NULL; // NULL out the third part :)

    // Build the pages...
    // Not a full template system so this should work...
    $this->pageinfo = array(
	 	"index"    => file_get_contents(THEME_PATH . '/home.html'),
		"about"    => file_get_contents(THEME_PATH . '/about.html'),
		"features" => file_get_contents(THEME_PATH . '/features.html'),
		"login"    => file_get_contents(THEME_PATH . '/login.html'),
		"register" => file_get_contents(THEME_PATH . '/register.html'),
		"error"    => file_get_contents(THEME_PATH . '/error.html'),
		"success"  => file_get_contents(THEME_PATH . '/success.html'),
		"pricing"  => file_get_contents(THEME_PATH . '/pricing.html'),
		"static"   => file_get_contents(THEME_PATH . '/static.html'),
		"users" => array(
			"index"     => file_get_contents(THEME_PATH . '/user-home.html'),
			"listforms" => file_get_contents(THEME_PATH . '/user-listforms.html'),
			"newform"   => file_get_contents(THEME_PATH . '/user-newform.html'),
		)
    );
    if(!array_key_exists(strtolower($act1),$this->pageinfo)){
      $this->page = str_replace("{TITLE}","$title",$this->pageinfo['index']);
    } else if(is_array($this->pageinfo[strtolower($act1)]) && !array_key_exists(strtolower($act2),$this->pageinfo[strtolower($act1)])){
      $this->page = str_replace("{TITLE}","$title",$this->pageinfo[strtolower($act1)]['index']);
    } else if(is_array($this->pageinfo[strtolower($act1)])){
      $this->page = str_replace("{TITLE}","$title",$this->pageinfo[strtolower($act1)][strtolower($act2)]);
    } else {
      $this->page = str_replace("{TITLE}","$title",$this->pageinfo[strtolower($action)]);
    }
    // Finish the rest of the variables! :)
    $this->page = str_replace("{STATIC_HEAD}","$statichead",$this->page);
    $this->page = str_replace("{STATIC_MSG}","$staticmsg",$this->page);
    $this->page = str_replace("{SLOGAN}","$slogan",$this->page);
    $this->page = str_replace("{COPYRIGHT}","$copyright",$this->page);
    $this->page = str_replace("{COMPANY}","$company",$this->page);
    $this->page = str_replace("{LIST_FORMS}","$forms",$this->page);
    $this->page = str_replace("{OWNER_EMAIL}","$owneremail",$this->page);
    $this->page = str_replace("{SITE_URL}","$siteurl",$this->page);
    $this->page = str_replace("{ERROR_MSG}","$errormsg",$this->page);
    $this->page = str_replace("{SUCCESS_MSG}","$successmsg",$this->page);
    if(!$_SESSION['username']){
      preg_match("/{IF_USER}(.*){\/IF_USER}/s",$this->page,$search);
      // Now let's replace everything
      foreach($search as $key => $val)
      {
        $this->page = str_replace($val,"",$this->page);
      }
      $this->page = str_replace("{IF_GUEST}","",$this->page);
      $this->page = str_replace("{/IF_GUEST}","",$this->page);
    } else {
      preg_match("/{IF_GUEST}(.*){\/IF_GUEST}/s",$this->page,$search);
      // Replace again
      foreach($search as $key => $val)
      {
        $this->page = str_replace($val,"",$this->page);
      }
      $this->page = str_replace("{IF_USER}","",$this->page);
      $this->page = str_replace("{/IF_USER}","",$this->page);
    }
    if($this->MAIN->session->checkAdmin() != true){
      preg_match("/{IF_ADMIN}(.*){\/IF_ADMIN}/s",$this->page,$search);
      foreach($search as $key => $val)
      {
        $this->page = str_replace($val,"",$this->page);
      }
    } else {
      $this->page = str_replace("{IF_ADMIN}","",$this->page);
      $this->page = str_replace("{/IF_ADMIN}","",$this->page);
    }
    return $this->page;
  }
}
?>