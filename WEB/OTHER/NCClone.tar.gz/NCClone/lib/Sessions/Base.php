<?php
/**
 * External Form Script
 *
 * File: lib/Sessions/Base.php
 * Description: Handles most of the session stuff as well as registration
 *
 * Author: Dennis McWherter
 *
 */
if(!defined("IS_SCRIPT")){
  print "Unauthorized Access!";
  exit;
}

class Sessions_Base
{
  /**
   * GlobVarZ
   *
   */
  var $MAIN;

  /**
   * Register function.
   *
   */
  function register($usr,$pass,$email)
  {
    // I might have said this before, but still.. Remember to escape all data that we don't provide before querying!
    $usr   = $this->MAIN->db->escape($usr);
    $pass  = $this->MAIN->db->escape($pass);
    $email = $this->MAIN->db->escape($email);
	
    $unencpass = $pass;
    $pass = md5($pass); // Encrypt pass

    // Let's run a few checks so we don't try to overwrite other users, etc.
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE user='".$usr."'");
    $this->MAIN->db->query();
    if($this->MAIN->db->num_rows() > 0){
      $this->MAIN->errormsg = "User already exists with that name!";
      print $this->MAIN->site->page("error");
      exit;
    }
    
    // Check if user really gave us a working email! - Use different vars so we don't mess
    // Things up going into the db!
    list($mailName,$mailAddr) = split("@",$email);
    if(!checkdnsrr($mailAddr,"MX")){
      $this->MAIN->errormsg = "Please enter a vaild email address!";
      print $this->MAIN->site->page("error");
      exit;
    }

    // Check if a user already registered with that address. Don't want people cheating the system!
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE email='".$email."'");
    $this->MAIN->db->query();
    if($this->MAIN->db->num_rows() > 0){
      $this->MAIN->errormsg = "There is already a user registered with that email address!";
      print $this->MAIN->site->page("error");
      exit;
    }

    // All went well now let's register the user after pulling a few things from the DB
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->config['prefix']}_settings LIMIT 1;");
    $this->MAIN->db->query();
    $row          = $this->MAIN->db->_array();
    $sitename     = stripslashes($row['title']);
    $owneremail   = stripslashes($row['owneremail']);
    $siteurl      = stripslashes($row['siteurl']);
    $mail['body'] = stripslashes($row['mailbody']);

    // Replace MailBody Vars
    $mail['body']   = str_replace("{USERNAME}","$usr",$mail['body']);
    $mail['body']   = str_replace("{PASSWORD}","$unencpass",$mail['body']);
    $mail['body']   = str_replace("{SITENAME}","$sitename",$mail['body']);
    $mail['body']   = str_replace("{SITE_URL}","$siteurl",$mail['body']);
    $mail['header'] = $sitename." - Account E-mail";

    $this->MAIN->db->build_query("INSERT INTO {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users VALUES('NULL', '".$usr."', '".$pass."', '".$email."', 'User', '".$_SERVER['REMOTE_ADDR']."', '".date("Y-m-d")."', '".date("Y-m-d")."', '0', 'Pending');");
    $this->MAIN->db->query();			

    if(mail($email,$mail['header'],$mail['body'],"From: \"$sitename\" <$owneremail>"))
    {
      $this->MAIN->successmsg = "User Registered Successfull!";
      print $this->MAIN->site->page("success");
    }
    // Keep moving.. Make the user directory..
    mkdir(USER_PATH . "/".$usr, 0777);
  }

  /** 
   * CheckAdmin Permissions!
   *
   */
  public function checkAdmin()
  {
    if(!$_SESSION['username']){
      return false;
    } else {
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE user='{$this->MAIN->db->escape($_SESSION['username'])}' AND perms='Admin'");
      $this->MAIN->db->query();
      if($this->MAIN->db->num_rows() != 1){
        return false;
      }
      return true;
    }
  }

  /**
   * Login
   *
   * @param string $user, $pass
   * @return bool
   *
   */
  function login($user,$pass)
  {
    $pass = md5($pass);
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE user='{$this->MAIN->db->escape($user)}' AND password='{$this->MAIN->db->escape($pass)}'");
    $this->MAIN->db->query();
    $userinfo = $this->MAIN->db->_array();
    if($this->MAIN->db->num_rows() != 1){
      $this->MAIN->errormsg = "Invalid login credentials!";
      print $this->MAIN->site->page("error");
      exit;
    } else {
      $_SESSION['username'] = $userinfo['user'];
      $this->MAIN->db->build_query("UPDATE {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users set ip='".$_SERVER["REMOTE_ADDR"]."' lastlogin='".date('Y-m-d')."' WHERE user='{$this->MAIN->db->escape($user)}'");
      $this->MAIN->db->query();
      $this->MAIN->successmsg = "Login Successful! Please continue <a href=\"?act=index\">home</a>.";
      print $this->MAIN->site->page("success");
      return true;
    }
    return false;
  }

  /**
   * Logout.. Simple :)
   *
   */
  function logout()
  {
    if(!$_SESSION['username']){
      $this->MAIN->errormsg = "You are not logged in!";
      print $this->MAIN->site->page("error");
      exit;
    } else {
      session_destroy();
      $this->MAIN->successmsg = "You have successfully logged out!";
      print $this->MAIN->site->page("success");
    }
  }

  /**
   * Random Pass Generator
   *
   */
  function generatePass($charlimit=10)
  {
    $pass = ""; // Make sure var is blank
    $i    = ""; // Blank iterator
    $chars = "0123456789AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz!@#$%^&*(),./";

    while($i<$charlimit){
      $addchar = substr($chars,mt_rand(0,strlen($chars)-1),1);

      // Make sure that we don't have any of the same chars to keep this secure
      if(!strstr($pass,$addchar)){
        $pass .= $addchar;
        $i++;
      }
    }
    return $pass;
  }

  /**
   * Reset Pass
   *
   * var $user
   *
   */
  function resetPass($user,$ip)
  {
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE user='".$this->MAIN->db->escape($user)."'");
    $this->MAIN->db->query();

    // Fail if user doesn't exist!
    if($this->MAIN->db->num_rows() != 1){
      $this->MAIN->errormsg = "User ".$user." does not exist!";
      print $this->MAIN->site->page("error");
      return false;
    }

    // Checks cleared send the new password to the email on file! :)
    $userinfo = $this->MAIN->db->_array();
    $email = $userinfo['email'];

    // Now reset then send out the message! :D
    $newpass = $this->generatePass();

    $this->MAIN->db->build_query("UPDATE {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users SET password='".md5($newpass)."' WHERE user='".$this->MAIN->db->escape($user)."'");
    if(!$this->MAIN->db->query()){
      $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
      print $this->MAIN->site->page("error");
      exit;
    }
    $mailmsg = "Hello ".$user.",\r\n Your password has been reset by IP: ".$ip.".\r\nYour new password is: ".$newpass."\nYou can change this information by logging into your control panel!\r\nRegards.";
    if(mail($email,"Password Reset",$mailmsg)){
      return true;
    }
   return false;
  }
}
?>