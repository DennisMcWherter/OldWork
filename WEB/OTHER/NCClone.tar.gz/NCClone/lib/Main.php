<?php
/**
 * External Form Script
 *
 * File: lib/Main.php
 * Description: Main function class :)
 *
 * Author: Dennis McWherter
 *
 */
if(!defined("IS_SCRIPT")){
  print "Unauthorized Access!";
  exit;
}

class MAIN
{
  /**
   * Config var!
   *
   * @var array
   *
   */
  var $config = array();

  /**
   * Session var :)
   *
   * @var object
   *
   */
  var $session;

  /**
   * DB Var
   *
   * @var object
   *
   */
  var $db;

  /**
   * Errors
   *
   * @var object
   *
   */
  var $errors = 0;

  /** 
   * Copyright var
   *
   */
  var $copyright = "&#0169; Copyright 2009 {COMPANY}. All Rights Reserved";

  /**
   * The error page
   *
   * @var string
   *
   */
  var $error_page = "<h1>Internal Server Error</h1><br />
                     <br />A server-side error occurred while loading the page!";

  /**
   * Constructors... Suckz0rz...
   *
   */
  function __construct()
  {
    if(!defined("INIT_SUCCESS") || "INIT_SUCCESS" != true){
      $this->errors++;
    }
  }

  /**
   * Our SQL Connection Stuff
   *
   */
  function sql_connect()
  {
    if(file_exists(CORE_PATH . "/SQL/Base.php")){
      // Redundancy is for script protection just in case pages
      // are added on and one forgets to include script essentials!
      require_once(CORE_PATH . "/SQL/Base.php");
      // Now let's do all the connection and such! :)
      $this->db = new SQL_Base($this->config);
      $this->db->connect();
      $this->db->select_db();

      if(!defined("SQL_Loaded")){
	define("SQL_Loaded", true);
      }
      return true;
    } else {
      $this->errors++; // Didn't work :(
    }
    return false;
  }
}
?>