<?php
/**
 * External Form Script
 *
 * File: lib/SQL/Base.php
 * Description: SQL Wrapper
 *
 * Author: Dennis McWherter
 *
 */
if(!defined("IS_SCRIPT")){
  print "Unauthorized Access!";
  exit;
}

class SQL_Base
{

  /**
   * Almighty Global Var :)
   *
   */
  var $MAIN;

  /**
   * MySQL Resource
   *
   * @var resource
   *
   */
  var $link;

  /**
   * Vars used by class
   *
   * @var array
   *
   */
  var $obj = array(
		"host" => "",
		"user" => "",
		"pass" => "",
		"db"   => ""
  );

  /**
   * MySQL Database
   *
   * @var resource
   *
   */
  var $db;

  /**
   * Unexecuted query string...
   *
   * @var string
   *
   */
  var $query_ue;

  /**
   * Query String
   *
   * @var string
   *
   */
  var $query;

  /**
   * Query string, not executed
   *
   * @var string
   */
  var $query_rs = '';
	
  /**
   * Number of queries
   *
   * @var int
   */
  var $num_queries = 0;

  /**
   * Array used to query the database
   *
   * @var array
   */
  var $query_array = array( );
	
  /**
   * Errors
   *
   * @var array
   */
  var $errors = array( );
	
 /**
  * Constructor again... grr...
  *
  * @param array $info
  * @return SQL_Base
  * 
  */
  function SQL_Base($info)
  {
    if(!is_array($info))
    {
      return("Incorrect SQL connection variables.");
    }
    if(array_key_exists("host",$info) && array_key_exists("user",$info)
    && array_key_exists("pass",$info) && array_key_exists( "db",$info)){
      $this->obj = $info;
    } else {
      return("Incorrect SQL connection variables.");
    }
  }
	
	/**
	 * Connecting to MySQL
	 *
	 * @param string $host
	 * @param string $user
	 * @param string $pass
	 * @return bool
	 * 
	 */
  function connect()
  {
    $this->link = mysql_connect($this->obj['host'], $this->obj['user'], $this->obj['pass']);
	
    return $this->link ? true : false;
  }
	
  function __destruct()
  {
    if($this->link)
    {
      mysql_close($this->link);
    }
  }
	
  /**
   * Selecting database for the MySQL connection
   *
   * @param string $db
   * @return bool
   *
   */
  function select_db()
  {
    $this->db = mysql_select_db($this->obj['db']);
		
    return $this->db ? true : false;
  }
	
  /**
   * Builds a query of either a string or an array
   * This is a real mess :( sorry
   *
   * @param mixed $query
   * 
   */
  function build_query($query)
  {
    $return = '';

    if(!is_array($query))
		{
      $this->query_ue			 = $query;
      $return					.= $query;
      $this->query_array		 = array( "QUERY BUILT AS STRING" );
     } else {
      if(array_key_exists('select', $query))
      {
	$return .= "SELECT " .$query['select']." ";
      }
      if(array_key_exists('from', $query))
      {
	$return .= "FROM ".$query['from']." ";
      }
      if(array_key_exists('where', $query))
      {
	$return .= "WHERE " .implode(" AND ", $query['where']). " ";
      }
      if(array_key_exists('limit', $query))
      {
	$return .= "LIMIT " .$query['limit']. " ";
      }
      if(array_key_exists('orderby', $query))
      {
	$return .= "ORDER BY " .$query['orderby']. " ";
      }
			
      $this->query_rs			= $return;
      $this->query_array		= $query;
      }
    return $return;
  }

 /**
  * Execute the query
  *
  * @param string $query
  * @return bool
  *
  */
  function exec($query)
  {
    $this->query = mysql_query($query);

    if(!$this->query)
    {
      $this->errors[] = array('errno' => mysql_errno(), 'errstr' => mysql_error());
    }
    $this->num_queries++;

    return $this->query ? true : false;
  }

  /**
   * Query the database
   *
   * @return bool
   * 
   */
  function query()
  {
    return $this->exec($this->query_ue);
  }
	
  /**
   * Escapes a string... MySQL Injections are a real bummer to wake up to :(
   *
   * @param string $string
   * @return string
   * 
   */
  public function escape($string)
  {
    if(version_compare(phpversion(),"4.3.0") == "-1") 
      return mysql_escape_string($string);
    else
        return mysql_real_escape_string($string);
  }

  /**
   * Returns number of selected rows
   *
   * @return int
   * 
   */
  public function num_rows()
  {
    return mysql_num_rows($this->query);
  }

  /**
   * Returns number of queries
   *
   * @return int
   *
   */
  public function get_num_queries()
  {
    return $this->num_queries;
  }

  /**
   * Creates an array of the latest query
   *
   * @return array
   * 
   * 
   */
  public function _array()
  {
    return mysql_fetch_array($this->query, MYSQL_BOTH);
  }
	
  /**
   * Creates an object of the latest query
   *
   * @return object
   * 
   *
   */
  public function _object()
  {
    return mysql_fetch_object($this->query());
  }
	
  /**
   * Free some memory
   *
   * @return bool
   * 
   *
   */
  public function free()
  {
    return mysql_free_result($this->query) ? true : false;
  }

  /**
   * ENCODE Function
   * Never store clear-text but sometimes we want the passwords back
   *
   * @param $unencpass
   *
   * @return string
   *
   */
  public function encode($unencpass)
  {
    $enc = mysql_query("SELECT ENCODE('$unencpass','')");
    $encstr = mysql_fetch_array($enc);
    $encval = $encstr[0];
    return($encval);
  }

  /**
   * DECODE Function
   * Never store clear-text but sometimes we want the passwords back
   * Yes, hackjobs on both but it was quick.
   *
   * @param $encpass
   *
   * @return string
   *
   */
  public function decode($encpass)
  {
    $dec = mysql_query("SELECT DECODE('$encpass','')");
    $decstr = mysql_fetch_array($dec);
    $decval = $decstr[0];
    return($decval);
  }	
}
?>