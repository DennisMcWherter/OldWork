<?php
/**
 * External Form Script
 *
 * File: lib/Users/Base.php
 * Description: All user functions, etc. are located here!
 *
 * Author: Dennis McWherter
 *
 */
if(!defined("IS_SCRIPT")){
  print "Unauthorized Access";
  exit;
}

class Users_Base
{
  /**
   * Sup3rGl0b4l
   *
   */
  var $MAIN;

  /**
   * Check for logged in
   *
   */
  function isLoggedIn()
  {
    if(!$_SESSION['username']){
      print $this->MAIN->site->page("login");
      exit;
    }
  }

  /**
   * We don't want to be hacked..
   * SOOOOO... Let's begin shall we? Stripping all harmful PHP code
   *
   */
  function filterPHP($data)
  {
    $data = preg_replace("/<\?((?!\?>).)*\?>/s"," ",$data);
    return $data;
  }

  /**
   * Make sure user is owner!
   *
   */
  function checkOwner($id=NULL,$user=NULL)
  {
    $this->isLoggedIn();
    if(isset($id)){
      $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE id='{$this->MAIN->db->escape($id)}' AND formowner='{$this->MAIN->db->escape($_SESSION['username'])}'");
      $this->MAIN->db->query();
      if($this->MAIN->db->num_rows() <= 0){
        $this->MAIN->errormsg = "This form does not belong to you!";
        print $this->MAIN->site->page("error");
        exit;
      } 
     } else if(isset($user)){
        $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users WHERE user='{$this->MAIN->db->escape($user)}'");
        $this->MAIN->db->query();
        if($this->MAIN->db->num_rows() <= 0){
          $this->MAIN->errormsg = "User does not exist!";
          print $this->MAIN->site->page("error");
          exit;
        }
      }
  }

  /**
   * List all user forms
   *
   */
  function listForms()
  {
    // Check if logged in
    $this->isLoggedIn();
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE formowner='{$this->MAIN->db->escape($_SESSION['username'])}'");
    $this->MAIN->db->query();
    while($row = $this->MAIN->db->_array()){
      $id       = stripslashes($row['id']);
      $name     = stripslashes($row['formname']);
      $domain   = stripslashes($row['formdomain']);
      $email    = stripslashes($row['formsendto']);
      $redirect = stripslashes($row['formredirect']);
      $status   = stripslashes($row['status']);
      $data     = stripslashes($row['formdata']);
      if($redirect == NULL){ $redirect = "No"; }
      if($email == NULL){ $email = "No"; }
      if($data == NULL){ $data = "No"; } else { $data = "<a href=\"?act=users&page=viewdata&id=".$id."\">View</a>"; }
      $this->MAIN->forms[] = "<p>".$name."&nbsp;".$domain."&nbsp;".$redirect."&nbsp;".$email."&nbsp;".$data."&nbsp;".$status."<a href=\"http://{SITE_URL}/users/".$_SESSION['username']."/".$domain.".php\" target=\"_blank\">View Form</a>&nbsp;<a href=\"?act=users&page=editform&id=".$id."\">Edit Form</a>&nbsp<a href=\"?act=users&page=delform&id=".$id."\">Delete Form</a></p>";
    }
    if($this->MAIN->forms == NULL){
      $this->MAIN->forms[] = "<br />You have no forms! Click <a href=\"?act=users&page=newform\">here</a> to add one!";
    }
    return $this->MAIN->site->page("users&listforms");
  }

  /**
   * Create new form
   *
   */
  function createForm($name,$code,$domain,$page,$owner,$store,$sendto,$redirect)
  {
    $this->isLoggedIn();
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE formname='{$this->MAIN->db->escape($this->filterPHP($name))}' AND formowner='{$this->MAIN->db->escape($this->filterPHP($owner))}'");
    $this->MAIN->db->query();
    if($this->MAIN->db->num_rows() > 0){
      $this->MAIN->errormsg = "You already have an existing for with this name. Please either edit that form or remove it.";
      print $this->MAIN->site->page("error");
      exit;
    }

    // Check if null!
    if($name == NULL OR $code == NULL OR $domain == NULL OR $page == NULL){
      $this->MAIN->error("You must input your form name, code, domain, and page!");
      print $this->MAIN->site->page("error");
      exit;
    }

    // All checks out, let's insert now...
    $this->MAIN->db->build_query("INSERT INTO {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms VALUES(NULL, '{$this->MAIN->db->escape($this->filterPHP($name))}', '{$this->MAIN->db->escape($this->filterPHP($code))}', '{$this->MAIN->db->escape($this->filterPHP($domain))}', '{$this->MAIN->db->escape($this->filterPHP($page))}', '{$this->MAIN->db->escape($this->filterPHP($owner))}', '{$this->MAIN->db->escape($this->filterPHP($sendto))}', '{$this->MAIN->db->escape($this->filterPHP($redirect))}', '{store}', 'Active')");
    $this->MAIN->db->query();

    // Going to make it so it's visible on a page!
    $file = fopen(USER_PATH . "/".$_SESSION['username']."/".$domain.".php",'w');
    $page = "
<?php
// Necessary information
include(\"../../config.php\");
mysql_connect(\$config['host'],\$config['user'],\$config['pass']);
mysql_select_db(\$config['db']);

// Declare form-specific data!
\$formname = \"".$name."\";
\$formowner = \"".$_SESSION['username']."\";

\$query = mysql_query(\"SELECT * FROM {\$config['prefix']}_forms WHERE formname='{\$formname}' AND formowner='{\$formowner}'\");

while(\$row = mysql_fetch_array(\$query)){
 \$page     = stripslashes(stripslashes(\$row['formpage']));
 \$code     = stripslashes(stripslashes(\$row['formcode']));
 \$data     = stripslashes(stripslashes(\$row['formdata']));
 \$mail     = stripslashes(stripslashes(\$row['formsendto']));
 \$redirect = stripslashes(stripslashes(\$row['formredirect']));
 \$status   = stripslashes(stripslashes(\$row['status']));
}
if(\$status == \"Inactive\"){ print \"Form inactive!\"; exit; }
if(\$data == NULL){ \$storedata = \"false\"; } else { \$storedata = \"true\"; }
if(\$redirect == NULL){ \$redirecturl = \"false\"; } else { \$redirecturl = \"\$redirect\"; }
if(\$mail == NULL){ \$mailto = \"false\"; } else { \$mailto = \"\$mail\"; }
mysql_close();
\$page = str_replace(\"{FORM}\",\"<form name=\\\"form\\\" method=\\\"post\\\" action=\\\"../process.php\\\">
			<input type=\\\"hidden\\\" name=\\\"store\\\" value=\\\"\$storedata\\\" />
			<input type=\\\"hidden\\\" name=\\\"mailto\\\" value=\\\"\$mailto\\\" />
			<input type=\\\"hidden\\\" name=\\\"redirect\\\" value=\\\"\$redirecturl\\\" />
			<input type=\\\"hidden\\\" name=\\\"formname\\\" value=\\\"\$formname\\\" />
			<input type=\\\"hidden\\\" name=\\\"formowner\\\" value=\\\"\$formowner\\\" />
			\$code</form>\",\$page);

print \$page;
?>";
    fwrite($file,$page);
    fclose($file);

    $this->MAIN->successmsg = "Your form has been successfully created!";
    return $this->MAIN->site->page("success");
  }

  /**
   * Grab form data for edit!
   *
   */
  function grabForm($id)
  {
    $this->isLoggedIn();
    $this->checkOwner($id);

    // Done with checks again.. hmmm... I'm hungry now XD
    $this->MAIN->db->build_query("SELECT * FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE id='{$this->MAIN->db->escape($id)}' AND formowner='{$this->MAIN->db->escape($_SESSION['username'])}'");
    while($row = $this->MAIN->db->_array()){
      $this->MAIN->formdata['name']     = stripslashes($row['formname']);
      $this->MAIN->formdata['code']     = stripslashes(stripslashes($row['formcode']));
      $this->MAIN->formdata['page']     = stripslashes(stripslashes($row['formpage']));
      $this->MAIN->formdata['domain']   = stripslashes($row['formdomain']);
      $this->MAIN->formdata['formdata'] = stripslashes($row['formdata']);
      $this->MAIN->formdata['owner']    = stripslashes($row['formowner']);
      $this->MAIN->formdata['sendto']   = stripslashes($row['formsendto']);
      $this->MAIN->formdata['redirect'] = stripslashes($row['formredirect']);
      $this->MAIN->formdata['status']   = stripslashes($row['status']);
    }
    return $this->MAIN->formdata;
  }

  /**
   * Delete forms!
   *
   */
  function delForm($id)
  {
    $this->isLoggedIn();
    $this->checkOwner($id);
    $this->grabForm($id);

    // Checks are a go 1st sgt... let's move..
    $this->MAIN->db->build_query("DELETE FROM {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms WHERE id='{$this->MAIN->db->escape($id)}' AND formowner='{$this->MAIN->db->escape($_SESSION['username'])}'");
    $this->MAIN->db->query();
    if(!$this->MAIN->db->query())
    {
      $this->MAIN->errormsg = "MySQL Error: ".mysql_error();
      return $this->MAIN->site->page("error");
      exit;
    }

    // Now let's remove the form file!
    unlink(USER_PATH . "/".$_SESSION['username']."/".$this->MAIN->formdata['domain'].".php");
    unset($this->MAIN->formdata);
    $this->MAIN->successmsg = "Form successfully deleted!";
    return $this->MAIN->site->page("success");
  }

  /**
   * Edit forms! :D yay
   *
   */
  function editForm($id)
  {
    $this->grabForm($id);
    if($_POST['inform'] == "true"){
      $this->MAIN->db->build_query("UPDATE {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_forms 
				   SET formname='".$this->MAIN->db->escape($_POST['name'])."', 
				formcode='".$this->MAIN->db->escape($this->filterPHP($_POST['code']))."', 
				formdomain='".$this->MAIN->db->escape($_POST['domain'])."', 
				formpage='".$this->MAIN->db->escape($_POST['page'])."', 
				formsendto='".$this->MAIN->db->escape($_POST['sendto'])."',
				formpage='".$this->MAIN->db->escape($_POST['page'])."',
				formredirect='".$this->MAIN->db->escape($_POST['redirect'])."', 
				status='".$this->MAIN->db->escape($_POST['status'])."' WHERE id='{$this->MAIN->db->escape($id)}' 
				AND formowner='{$this->MAIN->db->escape($_SESSION['username'])}'");

      if($this->MAIN->db->query()){
        $this->MAIN->successmsg = "Form edit successful!";
        return $this->MAIN->site->page("success");
      } else {
        $this->MAIN->errormsg = "MySQL Error:<br />".mysql_error();
	print $this->MAIN->site->page("error");
        return false;
      }
    }
  }

  /**
   * Edit Account Settings
   *
   */
  function editInfo($user,$pass1=NULL,$pass2=NULL,$email)
  {
    $this->isLoggedIn();
    $this->checkOwner(NULL,$_SESSION['username']);

    // Check pass..
    if($pass1 != ""){
      if($pass1 != $pass2){
        $this->MAIN->errormsg = "Your passwords do not match!";
        print $this->MAIN->site->page("error");
        return false;
      }
      $this->MAIN->db->build_query("UPDATE {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users
				SET password='".md5($pass1)."', email='".$email."'
				WHERE user='".$this->MAIN->db->escape($_SESSION['username'])."'");
    } else {
      $this->MAIN->db->build_query("UPDATE {$this->MAIN->db->escape($this->MAIN->config['prefix'])}_users
				SET email='".$email."'
				WHERE user='".$this->MAIN->db->escape($_SESSION['username'])."'");
    }
    if(!$this->MAIN->db->query()){
      $this->MAIN->errormsg = "MySQL Error: <br />".mysql_error();
      print $this->MAIN->site->page("error");
      return false;
    }
    $this->MAIN->successmsg = "Account Settings Successfully Changed!";
    print $this->MAIN->site->page("success");
    return true;
  }

  /**
   * View Data
   *
   */
  function viewData($id)
  {
    $this->isLoggedIn();
    $this->checkOwner($id);
    $this->grabForm($id);

    print "<h1>All Form Data</h1>".str_replace("\n","<br />",$this->MAIN->formdata['formdata'])."<br /><right><a href=\"?act=users&page=listforms\">Back</a>";
    return true;
  }
}
?>