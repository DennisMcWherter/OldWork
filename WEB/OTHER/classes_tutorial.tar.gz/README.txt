This tutorial was created by Dennis M. and is for FREE public use!

If you use any of my code, please give proper credit.

The link to this tutorial online is:
http://microsonic.org/2009/04/16/using-php-classes/

If you need any more help or would like to request a tutorial be made on the blog,
email me at dennis@microsonic.org.

(C) 2009 Dennis M. All Rights Reserved.

http://microsonic.org/
