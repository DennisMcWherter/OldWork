<?php
/**
 * Simple class by Dennis M.
 *
 */

// Class definition
class Test
{
	// Define variables here if any.
	var $test = NULL;

	/**
	 * Now, we have two ways to define our constructor.
	 * we can use function __construct() OR we can use
	 * function Test(). If __construct() and Test() are both
	 * used, then the class will use __construct. If not, it
	 * will look for Test(). If neither are defined, we don't 
	 * have a constructor XD
	 *
	 */
	function __construct(){
		/**
		 * Define actions in here that will
		 * take place for every function in the class!
		 * If you're not using a DB wrapper, then
		 * you can even define your mysql_connect()
		 * and mysql_select_db() in here so the functions
		 * don't have to do it later!
		 *
		 */
	}

	/**
	 * This next function allows us to print out information
	 * that is returned. Now, we're going to use two functions in here.
	 * The first function that is going to be defined is the public function
	 * for what we want to do. The second function, the check function,
	 * is going to be called within this function, but can only be called by a
	 * script like this because it's private and this function is within
	 * the class.
	 *
	 * It sounds much more confusing than it is in practice :)
	 * let's take a look.
	 *
	 * NOTICE: function text($param='val'). This defines an optional variable
	 *	   when calling the script later. E.g.: text("hello"); or $text();
	 *	   will both work. The first one will use "hello" and the second one
	 *	   will use the default value.
	 *
	 * @return string
	 *
	 */
	function text($say='test'){
		/**
	 	 * Let's run the check first.
		 * The check is a bool function so
		 * when we check for a response, we'll
		 * look for true or false.
		 *
	 	 * Note, because the function is within the
		 * class and it is separate from this one,
		 * we call it using the $this-> operator.
		 *
		 */
		if($this->check($say) != true){
			return "Could not find \"".$say."\" in the variable \$test.";
		}

		/**
		 * That was our only check. Now, let's 
		 * return a success message if	
		 * we got passed that!
		 * Realize that 'return' in a function is similar 
		 * to an 'exit' in non-function programming.
		 *
		 * Also, return always returns with a value unless
		 * you are creating a VOID function, in which case 
		 * you would just use return and no value would come back.
		 *
	 	 */
		return "Success! We found \"".$say."\" in the variable \$test!";
	}

	/**
	 * Here is the private function we were talking about.
	 *
	 * Private let's us know that no object outside the class "Test"
	 * can use this function.
	 *
	 * @return boolean
	 *
	 */
	private function check($say){
		/**
		 * We defined this variable earlier as
		 * null. Define it as string 'test'
		 * which is what the preceding function
		 * uses by default.
		 *
		 */
		$test = "test";
		if($say != $test){
			return false;
		}
		// That was the only check :)
		return true;
	}
}

class Test2 extends Test
{
	/**
	 * Note the "extends Test" defined after "class Test2"
	 * This makes Test2 an extension of "Test". In Test2
	 * you are now able to call all functions from Test
	 * using the $this-> operator except for the private
	 * functions. Those are still reserved for the Test class
	 * only.
	 *
	 */
	function w00t(){
		return $this->text();
	}
}

// Now we have ended the class but in order to initiate it we
// must define an operator. This is how:
$testclass  = new Test;
$testclass2 = new Test2;

// This WILL work
print "Test 4 should succeed: ".$testclass2->w00t()."<br /><br />";

// Now, we must use pointers to call to functions!
// This will NOT work.
print "Test 1 should fail: ".$testclass->text('w00t!')."<br /><br />";

// This WILL work
print "Test 2 should succeed: ".$testclass->text()."<br />OR<br />".$testclass->text('test')."<br /><br />";

// This WILL NOT work
print "Test 3 should fail: ";
print $testclass->check('test');
?>