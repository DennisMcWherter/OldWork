<?php
/**
 * Secure Cookies Tutorial by RageD
 * (C) 2008 RageD
 *
 */
if(!defined("IN_SCRIPT"))
{
	print "Unauthorized Access";
	exit;
}

class Cookie
{
    /**
     * Error variable...
     *
     */
    var $err = '0';

    /**
     * Constructor :)
     *
     */
    function __construct()
    {
        // I normally code a MySQL connector function in my scripts which would
        // work like $this->GLOBALVAR->connect();
        // But since this is a snippet, we'll just be using the basics
        mysql_connect('localhost','root','biker1');
        mysql_select_db('test');
        
        // See if we have any errors connecting...
        if(mysql_error())
        {
            $err++;
        }

        // Report errors
        if($err > 0)
        {
            print "We've encountered a MySQL Error!<br /><br />".mysql_error();
            exit;
        }
    }    

    /**
     * Login function, stores cookies, etc.
     *
     * @param $name
     * @param $pass
     * @bool $enc (true/false)
     */
    function login($name,$pass,$enc='true')
    {
        // Convert pass to md5 if encryption enabled. By default, it is.
        if($enc == true)
        {
            $pass = md5($pass);
        }

        // Now, let's continue! Query #1: Finding information :)
        $query = "SELECT * FROM users WHERE name='".$name."' AND pass='".$pass."' LIMIT 1;";
        $result = mysql_query($query);

        // Make sure the information given is valid
        if(mysql_num_rows($result) == 0)
        {
            print "Uh-oh! Incorrect login information.";
            exit;
        }

        // Passed the test, now set it...
        setcookie("PRACTICE[name]",$name, time()+3600); // Define the cookie. Let it expire after an hour
        setcookie("PRACTICE[pass]",$pass, time()+3600); // This is why encryption is recommended stores pass
	return;
    }

    /**
     * Logout function
     *
     * Deletes cookies :)
     *
     */
    function logout()
    {
        setcookie("PRACTICE[name]","", time()-10); // Send the cookies back, they forgot the milk! :(
        setcookie("PRACTICE[pass]","", time()-10); // No, seriously. The time()-10 means they expired 10 seconds ago
    }

    /**
     * Check function
     *
     * Finally, the security comes into play :)
     *
     */
    function check()
    {
	// Make sure a cookie is set too xD
	if($_COOKIE['PRACTICE']['name'] AND $_COOKIE['PRACTICE']['pass'])
	{
        	// Redundancy is beautiful *tear*
        	$query = "SELECT * FROM users WHERE name='".$_COOKIE['PRACTICE']['name']."' AND pass='".$_COOKIE['PRACTICE']['pass']."' LIMIT 1;";
        	$result = mysql_query($query);
        
        	// Check.. Grr.. They tried to pull a fast one :-| or something bugged?! :(
        	if(mysql_num_rows($result) == 0)
        	{
        	    print "Session Expired.";
		    $this->logout();
         	    exit;
        	} else {
            		if($_COOKIE['PRACTICE']['name'] AND $_COOKIE['PRACTICE']['pass'])
            		{
             	  	 print "It worked!"; // Probably can comment this out :)
            		}
		}
        }
    }
}
?>