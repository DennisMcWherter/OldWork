<?php
/**
 * Secure Cookies Tutorial by RageD
 * (C) 2008 RageD
 *
 */
// Script security :)
define("IN_SCRIPT", true);
require_once("functions.php");

// Define $session var for use of the "Cookie" class
$session = new Cookie;
$session->login("USER","PASS","false"); // Login :)
$session->check(); // Check
print "<br /><br />Let's print our cookie information:<br />Username: 
      ".$_COOKIE['PRACTICE']['name']."<br />
	Password: ".$_COOKIE['PRACTICE']['pass']."";

/**
 * I understand there are better ways to implement this into a script
 * However, my intent was to show the basics so people understand how
 * it all works. Other uses of the "Cookie" class (defined as $session) 
 * are below:
 *
 * $session->check(); // Will check cookies against DB
 * $session->login(USERNAME,PASSWORD,"true/false") // Enc should be 
 * either true or false. "True" recommended
 * $session->logout(); // Will obviously log a user out.
 *
 */

?>