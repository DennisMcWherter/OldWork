<?php
/**
* init.php for "Defining Paths in PHP" Tutorial by RageD
* (C) 2008 RageD
*
*/

/**
* This first one is simply for security. Accessing functions
* without proper access is bad :(
*
*/
define("SITE_SCRIPT", true);

/**
* Here we'll define the root path. Make sure that this file
* is in the ROOT directory! :)
*
*/
define("ROOT_PATH", dirname(__FILE__));

/**
* And finally.. Our includes. In this example it will be the
* "includes" directory.
*
*/
define("INC_PATH", ROOT_PATH . '/includes');

/**
* Final step... Make sure that this worked properly
* :)
*
*/
define("INIT_DONE", true);
?> 