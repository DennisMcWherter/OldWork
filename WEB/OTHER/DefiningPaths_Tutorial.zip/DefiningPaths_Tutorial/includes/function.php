<?php
/**
* includes/function.php for "Defining Paths in PHP" Tutorial by RageD
* (C) 2008 RageD
*
*/
// This is where that security definition comes into play :)
if(!defined("SITE_SCRIPT"))
{
     print("Unauthorized Access!");
     exit;
}

// Next, just a simple class and function example.
class Test
{
    /**
     * Constructor :)
     *
     */
    function __construct()
    {
        $this->text = "Hello World!<br />This script actually does work! :D";
    }

    /**
     * Basically just print $this->text
     *
     */
    function hello()
    {
        echo($this->text);
        exit;
    }
}
?> 