<?php
/**
 * includes/function.php for "Defining Paths in PHP" Tutorial by RageD
 * (C) 2008 RageD
 *
 */

// Place this file in the ROOT directory with init.php
require_once("init.php");

// Check if it worked properly or not
if(!defined("INIT_DONE"))
{
	echo("Doh! Houston, we have a problem. We did not initiate correctly!");
	exit;
}

// Get our function :D
require_once(INC_PATH . "/function.php");

$test = new Test; // Define our class so we can perform the function.

$test->hello(); // Run the function!
?>
