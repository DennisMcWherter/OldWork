<?php
/**
 * Simple Mailing List Script by Dennis M.
 * (C) 2009, Dennis M. All Rights Reserved.
 *
 */
// Config parameters
$emailfile = "emails.txt";
$msgfile   = "message.txt";
$subject   = "Message Subject";
$address   = "your@email.address";

// Grab emails and explode
$emails = file_get_contents($emailfile);
$emails = str_replace("\n",",",$emails);
$header    = "From: Your Name <".$address.">\r\n
	      BCC: ".$emails."\r\n";

// Now let's send an e-mail to each user and a copy to yourself
mail($address,$subject,file_get_contents($msgfile),$header);
print "Message sent to ".$address.",".$emails."<br />\n";

?>