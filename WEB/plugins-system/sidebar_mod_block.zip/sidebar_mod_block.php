<?php
/**
 * Sidebar Module by Dennis McWherter
 *
 * Format:
 * $sidebar_module['MOD_NAME']['OPTION'];
 *
 */
// Set module options
$sidebar_module['sidebar_mod_block']['enabled'] = "true"; // Enable/Disable Display
$sidebar_module['sidebar_mod_block']['type']    = "module"; // List as a link! Types = page or module
$sidebar_module['sidebar_mod_block']['link']    = "sidebar_mod_block"; // Should be the same name as the module
$sidebar_module['sidebar_mod_block']['title']   = "Sidebar Mod"; // Text to display

// Set page
if($_GET['page'] == $sidebar_module['sidebar_mod_block']['link']){
  print "Test<br />\nWorks properly! :)";
}

?>