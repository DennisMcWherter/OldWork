<?php
/**
 * Sample MOD by Dennis McWherter for iSource MOD Plugin System
 *
 */

// Test class
class Test{
  function Hello(){
    return "Hello world!";
  }
}
?>