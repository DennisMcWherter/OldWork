<?php
/**
 * Simple MOD by Dennis McWherter for iSource Directory Plugin System
 * 
 */
// Include proper files..
include_once("includes/class.php");

// Init class
$test = new Test;

// Run function included from file..
print $test->Hello();

?>